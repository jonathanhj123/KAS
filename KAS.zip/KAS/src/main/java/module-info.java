module KAS {
    requires javafx.controls;
    requires java.sql;
    exports gui;
}