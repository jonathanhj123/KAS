package model;

import java.util.ArrayList;

public class Firma {
    private String navn;
    private String tlf;
    private final ArrayList<Deltager> ansatte = new ArrayList<Deltager>();
}
